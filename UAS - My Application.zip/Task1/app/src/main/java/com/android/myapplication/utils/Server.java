package com.android.myapplication.utils;

public class Server {
    // sesuaikan dengan ip address pada perangkat dan folder file phpnya
    public static final String URL = "http://192.168.43.110/uas_project/";
}
