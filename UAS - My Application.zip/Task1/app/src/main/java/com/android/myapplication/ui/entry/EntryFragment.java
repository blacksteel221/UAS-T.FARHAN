package com.android.myapplication.ui.entry;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.android.myapplication.app.AppController;
import com.android.myapplication.databinding.FragmentEntryBinding;
import com.android.myapplication.utils.Server;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class EntryFragment extends Fragment {

    private FragmentEntryBinding binding;

    private final String url = Server.URL + "input_barang.php";
    public final static String TAG_USERNAME = "username";
    public final static String TAG_ID = "id";
    private static final String TAG = EntryFragment.class.getSimpleName();
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";
    public static final String my_shared_preferences = "my_shared_preferences";

    ProgressDialog pDialog;
    SharedPreferences sharedpreferences;
    String id, username;
    String tag_json_obj = "json_obj_req";

    public View onCreateView(@NonNull LayoutInflater inflater,ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentEntryBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        sharedpreferences = requireActivity().getSharedPreferences(my_shared_preferences, Context.MODE_PRIVATE);
        id = sharedpreferences.getString(TAG_ID, null);
        username = sharedpreferences.getString(TAG_USERNAME, null);

        binding.btnBatal.setOnClickListener(v -> clearText());
        binding.btnSimpan.setOnClickListener(v -> process());
        return root;
    }

    public void clearText(){
        binding.tvNamaBarang.setText("");
        binding.tvHargaBeli.setText("");
        binding.tvStokBarang.setText("");
    }

    private void process() {
        Objects.requireNonNull(binding.tvNamaBarang.getText()).toString();
        Objects.requireNonNull(binding.tvHargaBeli.getText()).toString();
        Objects.requireNonNull(binding.tvStokBarang.getText()).toString();
        try {
            InputBarang(binding.tvNamaBarang.getText().toString(), Integer.parseInt(binding.tvStokBarang.getText().toString()), Double.parseDouble(binding.tvHargaBeli.getText().toString()) );
        } catch (Exception e) {
            e.printStackTrace();
        }
        closeKeyboard();
    }

    private void closeKeyboard() {
        View view = requireActivity().getCurrentFocus();

        if (view != null) {
            InputMethodManager imm = (InputMethodManager) requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void InputBarang(final String nama, final int jumlah, final double harga_beli) {
        pDialog = new ProgressDialog(getContext());
        pDialog.setCancelable(false);
        pDialog.setMessage("Simpan Data ...");
        showDialog();

        StringRequest strReq = new StringRequest(Request.Method.POST, url, response -> {
            Log.e(TAG, "Input Data Response: " + response);
            hideDialog();

            try {
                JSONObject jObj = new JSONObject(response);
                int success = jObj.getInt(TAG_SUCCESS);

                // Check for error node in json
                if (success == 1) {

                    Log.e("Successfully Register!", jObj.toString());

                    Toast.makeText(requireActivity().getApplicationContext(),
                            jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();

                    binding.tvNamaBarang.setText("");
                    binding.tvStokBarang.setText("");
                    binding.tvHargaBeli.setText("");
                    binding.tvNamaBarang.setFocusable(true);

                } else {
                    Toast.makeText(requireActivity().getApplicationContext(),
                            jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                // JSON error
                e.printStackTrace();
            }

        }, error -> {
            Log.e(TAG, "Login Error: " + error.getMessage());
            Toast.makeText(requireActivity().getApplicationContext(),
                    error.getMessage(), Toast.LENGTH_LONG).show();

            hideDialog();

        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<>();
                params.put("nama", nama);
                params.put("stok", String.valueOf(jumlah));
                params.put("harga_beli", String.valueOf(harga_beli));
                params.put("entry_by", username);

                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_json_obj);
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}