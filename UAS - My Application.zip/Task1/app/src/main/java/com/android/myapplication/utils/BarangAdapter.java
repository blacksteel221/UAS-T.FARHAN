package com.android.myapplication.utils;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.myapplication.R;
import com.android.myapplication.model.Barang;


import java.util.List;

public class BarangAdapter extends RecyclerView.Adapter<BarangAdapter.ListViewHolder> {

    private List<Barang> listBarang;
    public void listBarangAdapter(List<Barang> list) {
        this.listBarang = list;
    }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_laporan, viewGroup, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ListViewHolder holder, int position) {
        Barang barang = listBarang.get(position);
        holder.tvName.setText(barang.getNamaBarang());
        holder.tvHargaJual.setText(String.valueOf(barang.getHargaJualBarang()));
        holder.tvHargabeli.setText(String.valueOf(barang.getHargaBeliBarang()));
        holder.tvQty.setText(String.valueOf(barang.getStokBarang()));
        holder.tvEntryBy.setText(String.valueOf(barang.getEntry_by()));
    }

    @Override
    public int getItemCount() {
        return listBarang.size();
    }

    static class ListViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvHargabeli, tvQty, tvHargaJual, tvEntryBy;

        ListViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_item_nama_barang);
            tvHargabeli = itemView.findViewById(R.id.tv_harga_beli_barang);
            tvHargaJual = itemView.findViewById(R.id.tv_harga_jual_barang);
            tvQty = itemView.findViewById(R.id.tv_item_jumlah_barang);
            tvEntryBy = itemView.findViewById(R.id.tv_entry_by);
        }
    }
}
