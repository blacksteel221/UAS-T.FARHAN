package com.android.myapplication.model;

public class Barang {
    private String namaBarang;
    private int hargaBeliBarang;
    private int hargaJualBarang;
    private int stokBarang;
    private String entry_by;

    public Barang() {

    }

    public String getNamaBarang() {
        return namaBarang;
    }

    public void setNamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }

    public int getHargaBeliBarang() {
        return hargaBeliBarang;
    }

    public void setHargaBeliBarang(int hargaBeliBarang) {
        this.hargaBeliBarang = hargaBeliBarang;
    }

    public int getHargaJualBarang() {
        return hargaJualBarang;
    }

    public void setHargaJualBarang(int hargaJualBarang) {
        this.hargaJualBarang = hargaJualBarang;
    }

    public int getStokBarang() {
        return stokBarang;
    }

    public void setStokBarang(int stokBarang) {
        this.stokBarang = stokBarang;
    }

    public String getEntry_by() {
        return entry_by;
    }

    public void setEntry_by(String entry_by) {
        this.entry_by = entry_by;
    }
}
