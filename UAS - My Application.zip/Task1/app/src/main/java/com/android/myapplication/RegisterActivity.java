package com.android.myapplication;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.myapplication.app.AppController;
import com.android.myapplication.databinding.ActivityRegisterBinding;
import com.android.myapplication.utils.Server;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class RegisterActivity extends AppCompatActivity {

    private ActivityRegisterBinding binding;

    ProgressDialog pDialog;
    Intent intent;
    String tag_json_obj = "json_obj_req";
    ConnectivityManager conMgr;
    int success;

    private final String url = Server.URL + "register.php";
    private static final String TAG = RegisterActivity.class.getSimpleName();
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        {
            if (conMgr.getActiveNetworkInfo() != null
                    && conMgr.getActiveNetworkInfo().isAvailable()
                    && conMgr.getActiveNetworkInfo().isConnected()) {
            } else {
                Toast.makeText(getApplicationContext(), "No Internet Connection",
                        Toast.LENGTH_LONG).show();
            }
        }


        binding.tvSignIn.setOnClickListener(v -> login());
        binding.btnRegister.setOnClickListener(v -> register());
    }

    private void register() {
        // TODO Auto-generated method stub
        String username = Objects.requireNonNull(binding.edtUsername.getText()).toString();
        String password = Objects.requireNonNull(binding.edtPassword.getText()).toString();
        String confirm_password = Objects.requireNonNull(binding.edtConfirmPassword.getText()).toString();
        String alamat = Objects.requireNonNull(binding.edtAddress.getText()).toString();
        String email = Objects.requireNonNull(binding.edtEmail.getText()).toString();
        String nama = Objects.requireNonNull(binding.edtFullName.getText()).toString();

        if (!password.equals(confirm_password)){
            Toast.makeText(getApplicationContext(), "Password yang anda masukkan tidak sama", Toast.LENGTH_SHORT).show();
            return;
        }

        if (conMgr.getActiveNetworkInfo() != null
                && conMgr.getActiveNetworkInfo().isAvailable()
                && conMgr.getActiveNetworkInfo().isConnected()) {
            checkRegister(username, password, nama, alamat, email);
        } else {
            Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
        }
    }

    private void login() {
        // TODO Auto-generated method stub
        intent = new Intent(RegisterActivity.this, LoginActivity.class);
        finish();
        startActivity(intent);
    }

    private void checkRegister(final String username, final String password, final String nama, final String alamat, final String email) {
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Register ...");
        showDialog();

        StringRequest strReq = new StringRequest(Request.Method.POST, url, response -> {
            Log.e(TAG, "Register Response: " + response);
            hideDialog();

            try {
                JSONObject jObj = new JSONObject(response);
                success = jObj.getInt(TAG_SUCCESS);

                // Check for error node in json
                if (success == 1) {

                    Log.e("Successfully Register!", jObj.toString());

                    Toast.makeText(getApplicationContext(),
                            jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();
                    binding.edtUsername.setText("");
                    binding.edtPassword.setText("");
                    binding.edtConfirmPassword.setText("");
                    binding.edtFullName.setText("");
                    binding.edtEmail.setText("");
                    binding.edtAddress.setText("");

                } else {
                    Toast.makeText(getApplicationContext(),
                            jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();
                    intent = new Intent(RegisterActivity.this, LoginActivity.class);
                    finish();
                    startActivity(intent);

                }
            } catch (JSONException e) {
                // JSON error
                e.printStackTrace();
            }

        }, error -> {
            Log.e(TAG, "Login Error: " + error.getMessage());
            Toast.makeText(getApplicationContext(),
                    error.getMessage(), Toast.LENGTH_LONG).show();

            hideDialog();

        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("password", password);
                params.put("nama", nama);
                params.put("alamat", alamat);
                params.put("email", email);
                params.put("jenis_kelamin", "Laki-Laki");

                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_json_obj);
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    @Override
    public void onBackPressed() {
        intent = new Intent(RegisterActivity.this, LoginActivity.class);
        finish();
        startActivity(intent);
    }

}