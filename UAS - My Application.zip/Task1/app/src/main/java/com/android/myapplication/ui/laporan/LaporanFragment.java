package com.android.myapplication.ui.laporan;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.android.myapplication.app.AppController;
import com.android.myapplication.databinding.FragmentLaporanBinding;
import com.android.myapplication.model.Barang;
import com.android.myapplication.utils.BarangAdapter;
import com.android.myapplication.utils.Server;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class LaporanFragment extends Fragment {

    private FragmentLaporanBinding binding;
    ProgressDialog pDialog;
    BarangAdapter adapter;

    private static final String TAG = LaporanFragment.class.getSimpleName();

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentLaporanBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        binding.rvLaporan.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.rvLaporan.setHasFixedSize(true);
        binding.rvLaporan.setAdapter(adapter);
        DataBarang();

        return root;
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    private void DataBarang() {
        pDialog = new ProgressDialog(getContext());
        pDialog.setCancelable(false);
        pDialog.setMessage("Loading ...");
        showDialog();

        String url = Server.URL + "lihatbarang.php";
        JsonArrayRequest jArr = new JsonArrayRequest(url, response -> {
            List<Barang> barangList = new ArrayList<>();
            try {

                for (int i = 0; i < response.length(); i++) {
                    JSONObject objek = response.getJSONObject(i);
                    Barang barang = new Barang();
                    barang.setNamaBarang(objek.getString("nama_barang"));
                    barang.setStokBarang(objek.getInt("jumlah"));
                    barang.setHargaBeliBarang(objek.getInt("hargabeli_barang"));
                    barang.setHargaJualBarang(objek.getInt("hargajual_barang"));
                    barang.setEntry_by(objek.getString("entry_by"));
                    barangList.add(barang);
                }
                adapter = new BarangAdapter();
                adapter.listBarangAdapter(barangList);
                binding.rvLaporan.setAdapter(adapter);
            } catch (JSONException e) {
                // JSON error
                e.printStackTrace();
            }
            hideDialog();


        }, error -> {
            VolleyLog.d(TAG, "Error: " + error.getMessage());
            Log.e(TAG, "Error: " + error.getMessage());
            Toast.makeText(requireActivity().getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();

            hideDialog();
        });

        // menambah request ke request queue
        AppController.getInstance().addToRequestQueue(jArr);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}