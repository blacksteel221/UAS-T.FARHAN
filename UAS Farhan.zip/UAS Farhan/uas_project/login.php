<?php
	include_once "koneksi.php";

	class usr{}

	$username = $_POST["username"];
	$password = $_POST["password"];

	$query = mysqli_query($con, "SELECT * FROM `tb_pengguna` WHERE `username`='$username' AND `password` = '$password'");

	$row = mysqli_fetch_array($query);

	if (!empty($row)){
	 	$response = new usr();
	 	$response->success = 1;
	 	$response->message = "Selamat datang ".$row['nama_lengkap'];
	 	$response->id = $row['id_user_inc'];
	 	$response->username = $row['username'];
	 	die(json_encode($response));

	} else {
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Username atau password salah";
	 	die(json_encode($response));
	}

	mysqli_close($con);
?>