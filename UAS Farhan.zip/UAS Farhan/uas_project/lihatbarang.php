<?php
	include_once "koneksi.php";

	class usr{}

	$query = mysqli_query($con, "SELECT * FROM `tb_barang`");
	$cek_data = mysqli_num_rows($query);
	$hasil = array();
	if ($cek_data != 0){
		while ($rowClient = mysqli_fetch_assoc($query)){
			$hasil[] = $rowClient;
		};
	 	die(json_encode($hasil));
	} else {
		$response = new usr();
		$response->success = 0;
		$response->message = "Data belum ada";
		die(json_encode($response));
 	}
	
	mysqli_close($con);

?>