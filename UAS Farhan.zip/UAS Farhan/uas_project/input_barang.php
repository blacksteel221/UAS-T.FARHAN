<?php
include_once "koneksi.php";

class usr
{
}

$nama = $_POST["nama"];
$stok = $_POST["stok"];
$harga_beli = $_POST["harga_beli"];
$entry_by = $_POST["entry_by"];
$harga_jual = $harga_beli + ($harga_beli * 0.1);

$query = mysqli_query($con, "INSERT INTO tb_barang (`nama_barang`, `hargabeli_barang`, `hargajual_barang`, `jumlah`, `entry_by`) VALUES('" . $nama . "','" . $harga_beli . "', '" . $harga_jual . "','" . $stok . "','" . $entry_by . "')");
if ($query) {
	$response = new usr();
	$response->success = 1;
	$response->message = "Barang berhasil ditambahkan.";
	die(json_encode($response));
} else {
	$response = new usr();
	$response->success = 0;
	$response->message = "Data Gagal Disimpan";
	die(json_encode($response));
}

mysqli_close($con);
?>