<?php
	include_once "koneksi.php";

	class usr{}

	$username = $_POST["username"];
	$password = $_POST["password"];
	$nama = $_POST["nama"];
	$alamat = $_POST["alamat"];
	$email = $_POST["email"];
	$jenis_kelamin = $_POST["jenis_kelamin"];

	if ((empty($username))) {
		$response = new usr();
		$response->success = 0;
		$response->message = "Kolom username tidak boleh kosong";
		die(json_encode($response));
	} else if ((empty($password))) {
		$response = new usr();
		$response->success = 0;
		$response->message = "Kolom password tidak boleh kosong";
		die(json_encode($response));
	} else {
		if (!empty($username)){
			$num_rows = mysqli_num_rows(mysqli_query($con, "SELECT * FROM tb_pengguna WHERE username='".$username."'"));

			if ($num_rows == 0){
				$query = mysqli_query($con, "INSERT INTO tb_pengguna (username, password, nama_lengkap, email, alamat, jenis_kelamin) VALUES('".$username."','".$password."', '".$nama."', '".$email."', '".$alamat."', '".$jenis_kelamin."')");

				if ($query){
					$response = new usr();
					$response->success = 1;
					$response->message = "Register berhasil, silahkan login.";
					die(json_encode($response));

				} else {
					$response = new usr();
					$response->success = 0;
					$response->message = "Ada kesalahan dalam menyimpan data";
					die(json_encode($response));
				}
			} else {
				$response = new usr();
				$response->success = 0;
				$response->message = "Username sudah ada";
				die(json_encode($response));
			}
		}
	}

	mysqli_close($con);
?>